<?php

require_once '../app/loader.php';

// alustetaan core kirjasto 
$init = new Core;

