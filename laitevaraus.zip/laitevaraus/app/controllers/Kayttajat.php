<?php
class Kayttajat extends Controller {

    public function __construct(){
        $this->kayttajaModel = $this->model('Kayttaja');
    }

    public function login(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //käsitellään lomakkeen tiedot
            
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            //Alustetaan data
            $data = [
                'sahkoposti' => trim($_POST['sahkoposti']),
                'salasana' => trim($_POST['salasana']),
                'sahkoposti_err' => '',
                'salasana_err' => ''
            ];

            $valid = true;

            if(empty($data['sahkoposti'])){
                $data['sahkoposti_err'] = 'Syötä sähköposti';
                $valid = false;
            }

            if(empty($data['salasana'])){
                $data['salasana_err'] = 'Syötä salasana';
                $valid = false;
            }

            if($this->kayttajaModel->findKayttajaBySahkoposti($data['sahkoposti'])){
                //käyttäjä löytyy
            }else{
                //käyttäjää ei löydy
                $data['sahkoposti_err'] = 'Käyttäjää ei olemassa';
                $valid = false;
            }

            //validointi ok
            if($valid == true) {
                $loggedInKayttaja = $this->kayttajaModel->login($data['sahkoposti'], $data['salasana']);

                if($loggedInKayttaja){
                    //luodaan SESSION
                    $this->createKayttajaSession($loggedInKayttaja);
                }else{
                    //ladataan ui virheilmoitusten kanssa
                    $data['salasana_err'] = 'Salasana virheellinen';
                    
                    $this->view('kayttajat/login', $data);
                }

            } else {
                //ladataan ui virheilmoitusten kanssa
                $this->view('kayttajat/login', $data);
            }

        }else{

            //Alustetaan data
            $data = [
                'sahkoposti' => '',
                'salasana'=> '',
                'sahkoposti_err' => '',
                'salasana_err' => ''
            ];
        }

        $this->view('kayttajat/login', $data);
    }

    public function register(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //käsitellään lomakkeen tiedot
            
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            //Alustetaan data
            $data = [
                'nimi' => trim($_POST['nimi']),
                'sahkoposti' => trim($_POST['sahkoposti']),
                'salasana'=> trim($_POST['salasana']),
                'confirm_salasana' => trim($_POST['confirm_salasana']),
                'nimi_err' => '',
                'sahkoposti_err' => '',
                'salasana_err' => '',
                'confirm_salasana_err'=> ''
            ];

            $valid = true;
            //tarkistetaan käyttäjän syötteet
            if(empty($data['nimi'])){
                $data['nimi_err'] = 'Syötä nimesi';
                $valid = false;
            }

            if(empty($data['sahkoposti'])){
                $data['sahkoposti_err'] = 'Syötä sähköposti';
                $valid = false;
            } else {
                //tarkistetaan että sahkoposti ei ole jo käytössä
                if($this->kayttajaModel->findKayttajaBySahkoposti($data['sahkoposti'])){
                    $data['sahkoposti_err'] = 'Sähköpostiosoite oli jo käytetty';
                    $valid = false; 
                }
            }

            if(empty($data['salasana'])){
                $data['salasana_err'] = 'Syötä salasana';
                $valid = false;
            }elseif(strlen($data['salasana']) < 6){
                $data['salasana_err'] = 'Salasana pituus vähintään 6 merkkiä';
                $valid = false;
            }

            if(empty($data['confirm_salasana'])){
                $data['confirm_salasana_err'] = 'Syötä salasanan varmistus';
                $valid = false;
            }elseif($data['salasana'] != $data['confirm_salasana']){
                $data['salasana_err'] = 'Salasanat eivät täsmää';
                $valid = false;
            }

            if($valid == true){
               //Salasana hash
                $data['salasana'] = password_hash($data['salasana'], PASSWORD_DEFAULT);

                if($this->kayttajaModel->register($data)){
                    flash('register_success', 'Rekisteröinti onnistui');
                    redirect('kayttajat/login');
                } else{
                    die('jokin meni pieleen');
                }

            }else{
                $this->view('kayttajat/register', $data);
            }
        
        } else {
            // alustetaan data
            $data = [
                'nimi' => '',
                'sahkoposti' => '',
                'salasana'=> '',
                'confirm_salasana' => '',
                'nimi_err' => '',
                'sahkoposti_err' => '',
                'salasana_err' => '',
                'confirm_salasana_err'=> ''

            ];
        }
        // ladataan näkymä
        $this->view('kayttajat/register', $data);
    }

    public function createKayttajaSession($kayttaja){
        $_SESSION['kayttaja_id'] = $kayttaja->kayttajaID;
        $_SESSION['kayttaja_sahkoposti'] = $kayttaja->sahkoposti;
        $_SESSION['kayttaja_nimi'] = $kayttaja->nimi;
        redirect('posts');
    }

    public function logout(){
        unset($_SESSION['kayttaja_id']);
        unset($_SESSION['kayttaja_sahkoposti']);
        unset($_SESSION['kayttaja_nimi']);
        session_destroy();
        redirect('kayttajat/login');
    }
}