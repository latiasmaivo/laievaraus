<?php

class Posts extends Controller {

    public function __construct(){
        if(!isLoggedIn()){
            redirect('kayttajat/login');
        }

        $this->postModel = $this->model('Post');
        $this->userModel = $this->model('Kayttaja');
    }

    public function index(){

        // haetaan veistit kannasta
        $posts = $this->postModel->getPosts();

        $data = [
            'posts' => $posts
        ];

        $this->view('posts/index', $data);
    }

    public function add(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //käsitellään lomakkeen tiedot
            
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            //Alustetaan data
            $data = [
                'title' => trim($_POST['title']),
                'body' => trim($_POST['body']),
                'user_id' => $_SESSION['user_id'],
                'title_err' => '',
                'body_err' => ''
            ];

            $valid = true;
            //tarkistetaan käyttäjän syötteet
            if(empty($data['title'])){
                $data['title_err'] = 'Syötä otsikko';
                $valid = false;
            }

            if(empty($data['body'])){
                $data['body_err'] = 'Syötä viesti';
                $valid = false;
            } 

            if($valid == true){

                if($this->postModel->addPost($data)){
                    flash('post_message', 'Viesti lisätty');
                    redirect('posts');
                } else{
                    die('jokin meni pieleen');
                }

            }else{
                $this->view('posts/add', $data);
            }
        
        } else {
            // alustetaan data
            $data = [
                'title' => '',
                'body' => '',
                'user_id' => '',
                'title_err' => '',
                'body_err' => ''
            ];
        }
        // ladataan näkymä
        $this->view('posts/add', $data);
    }

    public function edit($id){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //käsitellään lomakkeen tiedot
            
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            //Alustetaan data
            $data = [
                'id' => $id,
                'title' => trim($_POST['title']),
                'body' => trim($_POST['body']),
                'user_id' => $_SESSION['user_id'],
                'title_err' => '',
                'body_err' => ''
            ];

            $valid = true;
            //tarkistetaan käyttäjän syötteet
            if(empty($data['title'])){
                $data['title_err'] = 'Syötä otsikko';
                $valid = false;
            }

            if(empty($data['body'])){
                $data['body_err'] = 'Syötä viesti';
                $valid = false;
            } 

            if($valid == true){
                if($this->postModel->updatePost($data)){
                    flash('post_message', 'Viesti päivitetty');
                    redirect('posts');
                } else{
                    die('jokin meni pieleen');
                }

            }else{
                $this->view('posts/edit', $data);
            }
        
        } else {
            // alustetaan data
            $post = $this->postModel->getPostById($id);

            //Tarkistetaan oikeus muokata viestiä
            if($post->user_id != $_SESSION['user_id']){
                redirect('posts');
            }

            $data = [
                'id' => $id,
                'title' => $post->title,
                'body' => $post->body
            ];

            // ladataan näkymä
            $this->view('posts/edit', $data);
        }  
    }

    public function delete($id){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){

            //haetaan kyseisen viestin tiedot tietokannasta
            $post = $this->postModel->getPostById($id);

            //Tarkistetaan oikeus viestin poistamiseen
            if($post->user_id !=$_SESSION['user_id']){
                redirect('posts');
            }

            if($this->postModel->deletePost($id)){
                flash('post_message', 'Viesti poistettu');
                redirect('posts');
            } else{
                die('jokin meni pieleen');
            }

        } else {
            redirect('posts');
        } 
    }

    public function show($id){

        $post = $this->postModel->getPostById($id);
        $user = $this->userModel->getUserById($post->user_id);

        $data = [
            'post' => $post,
            'user' => $user
        ];

        $this->view('posts/show', $data);
    }
}