<?php

class Sivut extends Controller {

    public function __construct(){    
    }

    public function index(){

        if(isLoggedIn()){
            redirect('sivut');
        }

        $data = [
            'title' => 'Laitevaraus',
            'description' => 'Tähän tulee sivuston tarkempi kuvaus...'
        ];

        $this->view('sivut/index', $data);
    }

    public function about(){
        $data = [
            'title' => 'Tietoa järjestelmästä',
            'description' => 'Järjestelmän kanssa voit varata laitteita ...'
        ];

        $this->view('sivut/about', $data);
    }
}