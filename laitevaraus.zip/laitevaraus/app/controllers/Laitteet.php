<?php

class Laitteet extends Controller {

    public function __construct(){
        if(!isLoggedIn()){
            redirect('kayttajat/login');
        }

        $this->laiteModel = $this->model('Laite');
    }

    public function add(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //käsitellään lomakkeen tiedot
            
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            //Alustetaan data
            $data = [
                'nimi' => trim($_POST['nimi']),
                'kategoria' => trim($_POST['kategoria']),
                'saatavuus' => trim($_POST['saatavuus']),
                'nimi_err' => '',
                'kategoria_err' => '',
                'saatavuus_err' => '' 

            ];

            $valid = true;
            //tarkistetaan käyttäjän syötteet
            if(empty($data['nimi'])){
                $data['nimi_err'] = 'Syötä nimi';
                $valid = false;
            }

            if(empty($data['kategoria'])){
                $data['kategoria_err'] = 'Syötä kategoria';
                $valid = false;
            } 

            if(empty($data['saatavuus'])){
                $data['saatavuus_err'] = 'Syötä saatavuus';
                $valid = false;
            } 

            if($valid == true){

                if($this->laiteModel->addLaite($data)){
                    flash('laite_message', 'Laite lisätty');
                    redirect('laitteet');
                } else{
                    die('jokin meni pieleen');
                }

            }else{
                $this->view('laitteet/add', $data);
            }
        
        } else {
            // alustetaan data
            $data = [
                'nimi' => '',
                'kategoria' => '',
                'saatavuus' => '',
                'nimi_err' => '',
                'kategoria_err' => '',
                'saatavuus_err' => ''
            ];
        }
        // ladataan näkymä
        $this->view('laitteet/add', $data);
    }

    public function delete($id){
        if($_SERVER['REQUEST_METHOD'] == 'GET'){

            if($this->laiteModel->deleteLaite($id)){
                flash('laite_message', 'Laite poistettu');
                redirect('laitteet');
            } else{
                die('jokin meni pieleen');
            }

        } else {
            redirect('laitteet');
        } 
    }

    public function index(){

        // haetaan joukkuueet kannasta
        $laitteet = $this->laiteModel->getLaite();

        $data = [
            'laitteet' => $laitteet
        ];

        $this->view('laitteet/index', $data);
    }
}