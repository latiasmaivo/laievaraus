<<?php require APPROOT . '/views/inc/header.php'; ?>
<a href="<?php echo URLROOT; ?>/laitteet" class="btn btn-light">
<i class="fa fa-backward"></i> Takaisin</a>
<h1><?php echo $data['post']->title; ?></h1>
<div class="bg-secondary text-white p-2 mb-3">
    Kirjoittanut <?php echo $data['user']->name; ?> 
    <?php echo $data['laite']->created_at; ?> 
</div>
<p><?php echo $data['laite']->body; ?></p>
<?php if($data['kayttaja']->id == $_SESSION['kayttajaID']) : ?>
    <hr>
    <a href="<?php echo URLROOT; ?>/laiteet/edit/<?php echo $data['laite']->id; ?>" class="btn btn-dark">Muokkaa</a>

    <form action="<?php echo URLROOT; ?>/laiteet/delete/<?php echo $data['laite']->id; ?>" class="pull-right" method="laite">
        <input type="submit" value="Poista" class="btn btn-danger">
    </form>
<?php endif; ?>
<?php require APPROOT . '/views/inc/footer.php'; ?>