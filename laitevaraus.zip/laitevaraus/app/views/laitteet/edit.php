<?php require APPROOT . '/views/inc/header.php'; ?>
<a href="<?php echo URLROOT; ?>/laitteet" class="btn btn-light">
<i class="fa fa-backward"></i> Takaisin</a>
<div class="card card-body bg-light mt-5">
    <h2>Muokkaa laitetta</h2>
    <p>Muokkaa alla olevan laitteen tietoja</p>
    
    <form action="<?php echo URLROOT; ?>/laitteet/edit/<?php echo $data['laiteID']; ?>" method="post">
    
        <div class="form-group">
            <label for="nimi">Nimi <sup>*</sup></label>
            <input type="text" name="nimi" class="form-control form-control-lg 
            <?php echo (!empty($data['nimi_err'])) ? 'is-invalid' : ''; ?>"
            value="<?php echo $data['nimi']; ?>">
            <span class="invalid-feedback"><?php echo $data['nimi_err']; ?></span>
        </div>

        <div class="form-group">
            <label for="kategoria">Kategoria <sup>*</sup></label>
            <textarea name="kategoria" class="form-control form-control-lg 
            <?php echo (!empty($data['kategoria_err'])) ? 'is-invalid' : ''; ?>"><?php echo $data['kategoria']; ?></textarea>
            <span class="invalid-feedback"><?php echo $data['kategoria_err']; ?></span>
        </div>

        <input type="submit" value="Tallenna" class="btn btn-success btn-block">

    </from>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>