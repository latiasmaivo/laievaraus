<?php require APPROOT . '/views/inc/header.php'; ?>
<a href="<?php echo URLROOT; ?>/laitteet" class="btn btn-light">
<i class="fa fa-backward"></i> Takaisin</a>
<div class="card card-body bg-light mt-5">
    <h2>Lisää laite</h2>
    <p>Täytä alla olevat tiedot</p>
    
    <form action="<?php echo URLROOT; ?>/laitteet/add" method="post">
    
        <div class="form-group">
            <label for="name">Nimi <sup>*</sup></label>
            <input type="text" name="nimi" class="form-control form-control-lg 
            <?php echo (!empty($data['nimi_err'])) ? 'is-invalid' : ''; ?>"
            value="<?php echo $data['nimi']; ?>">
            <span class="invalid-feedback"><?php echo $data['nimi_err']; ?></span>
        </div>

        <div class="form-group">
            <label for="kategoria">Kategoria <sup>*</sup></label>
            <input type="body" name="kategoria" class="form-control form-control-lg 
            <?php echo (!empty($data['kategoria_err'])) ? 'is-invalid' : ''; ?>"
            value="<?php echo $data['kategoria']; ?>">
            <span class="invalid-feedback"><?php echo $data['kategoria_err']; ?></span>
        </div>

        <div class="form-group">
            <label for="saatavuus">Saatavuus <sup>*</sup></label>
            <input type="text" name="saatavuus" class="form-control form-control-lg 
            <?php echo (!empty($data['saatavuus_err'])) ? 'is-invalid' : ''; ?>"
            value="<?php echo $data['saatavuus']; ?>">
            <span class="invalid-feedback"><?php echo $data['saatavuus_err']; ?></span>
        </div>



        <input type="submit" value="Tallenna" class="btn btn-success btn-block">

    </form>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>