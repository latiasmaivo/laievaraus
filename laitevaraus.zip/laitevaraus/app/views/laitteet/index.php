<?php require APPROOT . '/views/inc/header.php'; ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

<div class="container">
    <div class="row">
        <div class="col-12 col-sm-3">
            <div class="card bg-light mb-3">
                <div class="card-header bg-primary text-white text-uppercase"><i class="fa fa-list"></i> Kategoriat</div>
                <ul class="list-group category_block">
                    <li class="list-group-item"><a href="category.html">Kamerat</a></li>
                    <li class="list-group-item"><a href="category.html">Tietokoneet</a></li>
                    <li class="list-group-item"><a href="category.html">Oheislaitteet</a></li>
                    <li class="list-group-item"><a href="category.html">Äänilaitteet</a></li>
                    <li class="list-group-item"><a href="category.html">Muut laitteet</a></li>
                </ul>
            </div>
        </div>
        <div class="col">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <img class="card-img-top" src="img/kannettava.jpg" alt="Card image cap">
                        <div class="card-body">
                            <h4 class="card-title"><a href="product.html" title="View Product">Kannettava (DELL)</a></h4>
                            <p class="card-text">Tässä on DELL kannettava tietokone</p>
                            <div class="row">
                                <div class="col">
                                    <p class="btn btn-danger btn-block">* Saatavuus *</p>
                                </div>
                                <div class="col">
                                    <a href="#" class="btn btn-success btn-block">Lisää koriin</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <img class="card-img-top" src="img/asuslaptop.jpg" alt="Card image cap">
                        <div class="card-body">
                            <h4 class="card-title"><a href="product.html" title="View Product">Kannettava (ASUS)</a></h4>
                            <p class="card-text">Tässä on ASUS kannettava tietokone</p>
                            <div class="row">
                                <div class="col">
                                    <p class="btn btn-danger btn-block">* Saatavuus *</p>
                                </div>
                                <div class="col">
                                    <a href="#" class="btn btn-success btn-block">Lisää koriin</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <img class="card-img-top" src="img/mikrophoni1.jpg" alt="Card image cap">
                        <div class="card-body">
                            <h4 class="card-title"><a href="product.html" title="View Product">Mikrophoni</a></h4>
                            <p class="card-text">Audio Technica mikrophoni</p>
                            <div class="row">
                                <div class="col">
                                    <p class="btn btn-danger btn-block">* Saatavuus *</p>
                                </div>
                                <div class="col">
                                    <a href="#" class="btn btn-success btn-block">Lisää koriin</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <img class="card-img-top" src="img/mikrophoni2.jpg" alt="Card image cap">
                        <div class="card-body">
                            <h4 class="card-title"><a href="product.html" title="View Product">Mikrophoni</a></h4>
                            <p class="card-text">Blue Yeti mikrophoni</p>
                            <div class="row">
                                <div class="col">
                                    <p class="btn btn-danger btn-block">* Saatavuus *</p>
                                </div>
                                <div class="col">
                                    <a href="#" class="btn btn-success btn-block">Lisää koriin</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <img class="card-img-top" src="img/canonkamera.jpg" alt="Card image cap">
                        <div class="card-body">
                            <h4 class="card-title"><a href="product.html" title="View Product">Kamera</a></h4>
                            <p class="card-text">Canon kamera</p>
                            <div class="row">
                                <div class="col">
                                    <p class="btn btn-danger btn-block">* Saatavuus *</p>
                                </div>
                                <div class="col">
                                    <a href="#" class="btn btn-success btn-block">Lisää koriin</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <img class="card-img-top" src="img/conkamera.jpg" alt="Card image cap">
                        <div class="card-body">
                            <h4 class="card-title"><a href="product.html" title="View Product">Konferenssikamera</a></h4>
                            <p class="card-text">Konferenssikamera</p>
                            <div class="row">
                                <div class="col">
                                    <p class="btn btn-danger btn-block">* Saatavuus *</p>
                                </div>
                                <div class="col">
                                    <a href="#" class="btn btn-success btn-block">Lisää koriin</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <nav aria-label="...">
                        <ul class="pagination">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Takaisin</a>
                            </li>
                            <li class="page-item active">
                                <a class="page-link" href="#">1 <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Seuraava</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

    </div>
</div>

<?php require APPROOT . '/views/inc/footer.php'; ?>