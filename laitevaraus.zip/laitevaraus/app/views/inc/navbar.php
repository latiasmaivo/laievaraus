<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-3">
  <div class="container">
    <a class="navbar-brand" href="<?php echo URLROOT; ?>"><?php echo SITENAME; ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
      <li class="nav-item">
          <a class="nav-link" href="<?php echo URLROOT; ?>/laitteet">Laitteet</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo URLROOT; ?>/posts">Kärry <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo URLROOT; ?>/sivut/about">Tietoa meistä</a>
        </li>
      </ul>

      <ul class="navbar-nav ml-auto">
        <?php if(isLoggedIn()) : ?>
        <li class="nav-item">
          <a class="nav-link" href="#">Tervetuloa <?php echo $_SESSION['kayttaja_nimi']; ?></a>
          <li class="nav-item">
          <a class="nav-link" href="<?php echo URLROOT; ?>/kayttajat/logout">Kirjaudu ulos</a>
        </li>
        </li>
        
        <?php else : ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo URLROOT; ?>/kayttajat/register">Rekisteröidy <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo URLROOT; ?>/kayttajat/login">Kirjaudu</a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>