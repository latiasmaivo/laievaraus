<?php require APPROOT . '/views/inc/header.php'; ?>
<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card card-body bg-light mt-5">
            <h2>Luo tili</h2>
            <p>Täytä alla oleva rekisteröintilomake</p>
            
            <form action="<?php echo URLROOT; ?>/kayttajat/register" method="post">
            
                <div class="form-group">
                    <label for="nimi">Nimi <sup>*</sup></label>
                    <input type="text" name="nimi" class="form-control form-control-lg 
                    <?php echo (!empty($data['nimi_err'])) ? 'is-invalid' : ''; ?>"
                    value="<?php echo $data['nimi']; ?>">
                    <span class="invalid-feedback"><?php echo $data['nimi_err']; ?></span>
                </div>

                <div class="form-group">
                    <label for="sahkoposti">Sähköposti <sup>*</sup></label>
                    <input type="sahkoposti" name="sahkoposti" class="form-control form-control-lg 
                    <?php echo (!empty($data['sahkoposti_err'])) ? 'is-invalid' : ''; ?>"
                    value="<?php echo $data['sahkoposti']; ?>">
                    <span class="invalid-feedback"><?php echo $data['sahkoposti_err']; ?></span>
                </div>

                <div class="form-group">
                    <label for="salasana">Salasana <sup>*</sup></label>
                    <input type="salasana" name="salasana" class="form-control form-control-lg 
                    <?php echo (!empty($data['salasana_err'])) ? 'is-invalid' : ''; ?>"
                    value="<?php echo $data['salasana']; ?>">
                    <span class="invalid-feedback"><?php echo $data['salasana_err']; ?></span>
                </div>

                <div class="form-group">
                    <label for="confirm_salasana">Varmista salasana <sup>*</sup></label>
                    <input type="salasana" name="confirm_salasana" class="form-control form-control-lg 
                    <?php echo (!empty($data['confirm_salasana_err'])) ? 'is-invalid' : ''; ?>"
                    value="<?php echo $data['confirm_salasana']; ?>">
                    <span class="invalid-feedback"><?php echo $data['confirm_salasana_err']; ?></span>
                </div>

                <div class="row">
                    <div class="col">
                        <input type="submit" value="Rekisteröidy" class="btn btn-success btn-block">
                    </div>
                    <div class="col">
                        <a href="<?php echo URLROOT; ?>/kayttajat/login" 
                        class="btn btn-light btn-block">Kirjaudu sisään</a>
                    </div>
                </div>
            </from>
        </div>
    </div>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>