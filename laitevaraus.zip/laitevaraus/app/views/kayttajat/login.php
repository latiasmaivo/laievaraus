<?php require APPROOT . '/views/inc/header.php'; ?>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card card-body bg-light mt-5">
            <?php flash('register_success'); ?>
            <h2>Kirjaudu sisään</h2>
            <p>Syötä sähköposti ja salasana</p>
            <form action="<?php echo URLROOT; ?>/kayttajat/login" method="post">
            
                <div class="form-group">
                    <label for="sahkoposti">Sähköposti <sup>*</sup></label>
                    <input type="sahkoposti" name="sahkoposti" class="form-control form-control-lg 
                    <?php echo (!empty($data['sahkoposti_err'])) ? 'is-invalid' : ''; ?>"
                    value="<?php echo $data['sahkoposti']; ?>">
                    <span class="invalid-feedback"><?php echo $data['sahkoposti_err']; ?></span>
                </div>

                <div class="form-group">
                    <label for="salasana">Salasana <sup>*</sup></label>
                    <input type="password" name="salasana" class="form-control form-control-lg 
                    <?php echo (!empty($data['salasana_err'])) ? 'is-invalid' : ''; ?>"
                    value="<?php echo $data['salasana']; ?>">
                    <span class="invalid-feedback"><?php echo $data['salasana_err']; ?></span>
                </div>

                <div class="row">
                    <div class="col">
                        <input type="submit" name="submit" value="Kirjaudu" class="btn btn-success btn-block">
                    </div>
                    <div class="col">
                        <a href="<?php echo URLROOT; ?>/kayttajat/register" 
                        class="btn btn-light btn-block">Rekisteröidy</a>
                    </div>
                </div>
    
            </form>
        </div>
    </div>

</div>

<?php require APPROOT . '/views/inc/footer.php'; ?>