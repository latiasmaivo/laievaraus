<?php

// ladataan asetukset
require_once 'config/config.php';
require_once 'helpers/url_helper.php';
require_once 'helpers/session_helper.php';

// ladata tarvittavat kirjastot
require_once 'libraries/core.php';
require_once 'libraries/controller.php';
require_once 'libraries/database.php';