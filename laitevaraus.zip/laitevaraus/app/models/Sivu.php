 <?php

 class Sivu {

 	private $db;

 	public function __construct(){
 		$this->db = new Database();
 	}

 }