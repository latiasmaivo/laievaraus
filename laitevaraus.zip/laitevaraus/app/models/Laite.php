<?php

class Laite {
    private $db;

    public function __construct(){
        $this->db = new Database;
    }


    public function addLaite($data){
        $this->db->query("INSERT INTO laite (nimi, kategoria, saatavuus) VALUES (:nimi, :kategoria, :saatavuus)");
        $this->db->bind(':nimi', $data['nimi']);
        $this->db->bind(':kategoria', $data['kategoria']);
        $this->db->bind(':saatavuus', $data['saatavuus']);

        //viedään tiedot kantaan
        if($this->db->execute()){
            return true;
        } else {
            return false;
        }
    }

    public function getLaite(){
        $this->db->query('
            SELECT *
            FROM laite
        ');

        $results = $this->db->resultSet();

        return $results;
    }

    public function deleteLaite($id){
        $this->db->query("DELETE FROM laite WHERE laiteID = :id");

        $this->db->bind(':id', $id);

    //suoritetaan sql-kysely
    if($this->db->execute()){
        return true;
    } else {
        return false;
    }
    }

}