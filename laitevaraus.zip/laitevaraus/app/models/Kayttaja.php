<?php

class Kayttaja {
    private $db;

    public function __construct(){
        $this->db = new Database;
    }

    public function findKayttajaBySahkoposti($sahkoposti){
        $this->db->query("SELECT * FROM kayttajat WHERE sahkoposti = :sahkoposti");
        $this->db->bind(':sahkoposti', $sahkoposti);

        $row = $this->db->single();

        //tarkistetaan mitä tietoja saatiin
        if($this->db->rowCount() > 0){
            return true;
        } else {
            return false;
        }
    }

    public function getKayttajaById($id){
        $this->db->query("SELECT * FROM kayttajat WHERE kayttajaID = :kayttajaID");
        $this->db->bind(':kayttajaID', $id);

        $row = $this->db->single();

        return $row;
    }


    public function login($sahkoposti, $salasana){
        $this->db->query("SELECT * FROM kayttajat WHERE sahkoposti = :sahkoposti");
        $this->db->bind(':sahkoposti', $sahkoposti);

        $row = $this->db->single();

        $hashed_password = $row->salasana;

        if(password_verify($salasana, $hashed_password)){
            return $row;
        } else {
            return false;
        }
    }

    public function register($data){
        $this->db->query("INSERT INTO kayttajat (nimi, sahkoposti, salasana) 
        VALUES (:nimi, :sahkoposti, :salasana)");
        $this->db->bind(':nimi', $data['nimi']);
        $this->db->bind(':sahkoposti', $data['sahkoposti']);
        $this->db->bind(':salasana', $data['salasana']);

        //viedään tiedot kantaan
        if($this->db->execute()){
            return true;
        } else {
            return false;
        }
    }

}