<?php
// peruskontrolleri
// ladata mallit ja näkymät

class Controller {

    //ladataan tietomalli
    public function model($model){
        // ladataan tarvittava tiedosto
        require_once '../app/models/' . $model . '.php';

        // alustetaan malli
        return new $model();

    }

    // ladataan näkymä
    public function view($view, $data = []){
        if(file_exists('../app/views/' . $view . '.php')){
            // ladataan tiedosto jos olemassa
            require_once '../app/views/' . $view . '.php';  
        } else {
            die('Näkymää ei olemassa');
        }
    }
}