<?php

//uudelleen ohjaus
function redirect($page){
    header('location: '. URLROOT . '/' . $page);
}