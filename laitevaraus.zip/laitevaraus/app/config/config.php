<?php
    // tietokannan asetukset
    define('DB_HOST', 'localhost');
    define('DB_USER', 'laitevaraus');
    define('DB_PASS', '123456');
    define('DB_NAME', 'laitevaraus');

    // Yleiset asetukset
    // url root 
    // sivuston nimi
    define('APPROOT', dirname(dirname(__FILE__)));
    define('URLROOT', 'http://localhost/laitevaraus');
    define('SITENAME', 'Laitevarausjärjestelmä');
    define('APPVERSION', '1.0.0');